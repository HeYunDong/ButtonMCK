//
//  AppDelegate.h
//  ButtonMC
//
//  Created by 何云东 on 2019/3/6.
//  Copyright © 2019 HYDBTMC. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;


@end

