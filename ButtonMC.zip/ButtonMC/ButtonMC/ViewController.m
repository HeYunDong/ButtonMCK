//
//  ViewController.m
//  ButtonMC
//
//  Created by 何云东 on 2019/3/6.
//  Copyright © 2019 HYDBTMC. All rights reserved.
//

#import "ViewController.h"
#define defaultInterval 3  //默认时间间隔



@interface ViewController ()

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    //runtime 机制
    UIButton * button = [UIButton buttonWithType:UIButtonTypeSystem];
    button.frame = CGRectMake(100, 100, 80, 50);
    [button setTitle:@"00" forState:UIControlStateNormal];
    [button addTarget:self action:@selector(testChlick:) forControlEvents:UIControlEventTouchUpInside];
    
    [self.view addSubview:button];
    button.eventTimeInterval = defaultInterval;
    
    
    UIButton * buttonone = [UIButton buttonWithType:UIButtonTypeSystem];
    buttonone.frame = CGRectMake(100, 160, 80, 50);
    [buttonone setTitle:@"11" forState:UIControlStateNormal];
    [buttonone addTarget:self action:@selector(testChlickoneone:) forControlEvents:UIControlEventTouchUpInside];
    
    [self.view addSubview:buttonone];
    
    
    
//    UIButton * buttontwo = [UIButton buttonWithType:UIButtonTypeSystem];
//    buttontwo.frame = CGRectMake(100, 240, 80, 50);
//    [buttontwo setTitle:@"22" forState:UIControlStateNormal];
//    [buttontwo addTarget:self action:@selector(testChlicktwo:) forControlEvents:UIControlEventTouchUpInside];
//
//    [self.view addSubview:buttontwo];
    
    


    
    // Do any additional setup after loading the view, typically from a nib.
}

-(void)testChlick:(id)sender{
    
    NSLog(@"====点击runtime===========0");
}


-(void)testChlickoneone:(UIButton * )sender{
    
    sender.enabled = NO;
    NSLog(@"====点击=one==========1");

    dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(defaultInterval * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{

        sender.enabled = YES;
    });
}

-(void)testChlicktwo:(UIButton * )sender{

    NSLog(@"====点击=two==========2");
    [NSObject cancelPreviousPerformRequestsWithTarget:self selector:@selector(buttonClickedAction:) object:sender];
    [self performSelector:@selector(buttonClickedAction:) withObject:sender afterDelay:defaultInterval];

}


///**
// *  取消延迟执行
// *
// *  @param aTarget    一般填self
// *  @param aSelector  延迟执行的方法
// *  @param anArgument 设置延迟执行时填写的参数（必须和上面performSelector方法中的参数一样）
// cancelPreviousPerformRequestsWithTarget  注意
// */
////




@end
