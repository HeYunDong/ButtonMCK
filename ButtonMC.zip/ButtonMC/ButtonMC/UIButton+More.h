//
//  UIButton+More.h
//  ButtonMC
//
//  Created by 何云东 on 2019/3/6.
//  Copyright © 2019 HYDBTMC. All rights reserved.
//

#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN

@interface UIButton (More)


/**
 设置点击的时间间隔
 */
@property (nonatomic, assign) NSTimeInterval eventTimeInterval;


@end

NS_ASSUME_NONNULL_END
